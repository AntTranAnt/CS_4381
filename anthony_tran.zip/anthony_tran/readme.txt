File contains pdf and lines.java, as well as compilation files from lines.java

For question 1 run lines.java, make sure you have java installed.